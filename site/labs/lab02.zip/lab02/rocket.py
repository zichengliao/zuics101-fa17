for counter in range(10,0,-1):
    print(counter)
print('Blast off!')
